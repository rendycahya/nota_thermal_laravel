let tbody = document.querySelector("#show");
let tbodydummy = document.querySelector("#dummy");
let arr = [];
let index = 0;
let penampung = 0;
let url = simpanNota.getAttribute("action");
let tampungSemua = '';
let data = '';
let jumlah = 0;
let tampungPembayaran = '';
let tampungJenisTransaksi = '';


function pembayaran(){
    let uang_dibayar = document.getElementById('uang_dibayar').value;
    let uang_kembali = uang_dibayar - penampung;
    document.getElementById('uang_kembali').innerHTML = Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(uang_kembali);
    let nama_pembeli = document.getElementById('nama_pembeli').value;

    tampungSemua = {
            'barang' : arr,
            'total_semua' : penampung, 
            'uang_dibayar' : Number(uang_dibayar),
            'uang_kembali' : uang_kembali,
            'nama_pembeli' : nama_pembeli,
            'metode_pembayaran' : tampungPembayaran,
            'jenis_transaksi' : tampungJenisTransaksi,
    };
    console.log(tampungSemua);
}

function calculate(){
    var rows = document.querySelectorAll("tr.input");
    rows.forEach(function (currentRow){
        var banyak_barang = Number(currentRow.querySelector('#banyak_barang').value);
        var harga_barang = Number(currentRow.querySelector('#harga_barang').value);
        document.querySelectorAll('banyak_barang');
        jumlah = banyak_barang * harga_barang;
        let tampiljumlah = jumlah;      

        currentRow.querySelector("#total_harga_barang").innerHTML = Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(tampiljumlah);
    });
}

//Simpan
function simpanData(){
    let nama_barang = document.getElementById('nama_barang').value;
    let banyak_barang = document.getElementById('banyak_barang').value;
    let harga_barang = document.getElementById('harga_barang').value;
    let barang = {
        'index' : index,
        'nama_barang' : nama_barang,
        'banyak_barang' : banyak_barang,
        'harga_barang' : harga_barang,
        'total_harga_barang' : jumlah,
    }

    arr.push(barang);

    document.getElementById('nama_barang').value = "";
    document.getElementById('banyak_barang').value = "";
    document.getElementById('harga_barang').value = "";
    document.getElementById("total_harga_barang").innerHTML = "";

    while(tbodydummy.hasChildNodes())
    {
        tbodydummy.removeChild(tbodydummy.firstChild);
    }

    let tr = tbody.insertRow();
    tr.id = index;
    tr.insertCell().innerHTML = "#";
    tr.insertCell().innerHTML = nama_barang;
    tr.insertCell().innerHTML = banyak_barang;
    tr.insertCell().innerHTML = Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(harga_barang);
    tr.insertCell().innerHTML = Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(jumlah);
    tr.insertCell().innerHTML = "<button onclick='editData(" + index + ")' class='btn btn-outline-dark'>Edit</button> | <button onclick='deleteData(" + index + ")' class='btn btn-outline-danger'>Hapus</button>";
    index++;  

    penampung = 0;
    for(let i = 0; i<arr.length; i++){
        penampung += parseInt(arr[i]['total_harga_barang']);
    }

    document.getElementById('total_semuanya').innerHTML = Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(penampung);
    jumlah = 0;
};

//SimpanNota
function SimpanNota(){
    // let input = document.querySelector('input[type="file"]');
    // console.log(input);
    let dataSimpan = new FormData();

    if(tampungPembayaran == 'Cash'){
        dataSimpan.append('file','')
        dataSimpan.append('semua', JSON.stringify(tampungSemua))
    }else if(tampungPembayaran == 'Transfer'){
        var input = document.querySelector('input[type="file"]');
        dataSimpan.append('file',input.files[0]);
        dataSimpan.append('semua',JSON.stringify(tampungSemua));
        // console.log()
    }

    console.log(dataSimpan);

    simpanNota.onsubmit = async(e) => {
        e.preventDefault();

        let response = await fetch(url,{
            method: 'POST',
            credentials: 'same-origin',
            headers: {
            // 'Content-Type': 'application/json',
            "X-CSRF-Token": document.querySelector('input[name=_token]').value,
            },
            body: dataSimpan,
        });

        console.log(response);
        let result = response;
        await result.json().then(function(res) {
            data = res;
            console.log(data);
        });

        // let urlprint = "{{ url('/print/{data.id}') }}";
        if (result.status == 200) {
            let print = confirm('Nota Berhasil Tersimpan, Print atau tidak ?');
            if (print){
                window.open('/cetakNota/'+ data.id, '_blank');
                location.reload();
            }else{
                location.reload();
                return false;
            }
        }
    }
}


function editData(id){
    let indexof = arr.findIndex(o => o.index === id);
    document.getElementById('nama_barang').value = arr[indexof].nama_barang;
    document.getElementById('banyak_barang').value = arr[indexof].banyak_barang;
    document.getElementById('harga_barang').value = arr[indexof].harga_barang;
    document.getElementById('total_harga_barang').innerHTML = arr[indexof].total_harga_barang;
    let onklik = document.querySelector("#save");
    onklik.setAttribute("onclick","updateBarang("+ id +")");
    onklik.innerHTML = "Update Barang";

}

function updateBarang(id){
    let indexof = arr.findIndex(o => o.index === id);
    // console.log(indexof);
    let nama_barang = document.getElementById('nama_barang').value;
    let banyak_barang = document.getElementById('banyak_barang').value;
    let harga_barang = document.getElementById('harga_barang').value;
    // let total_harga_barang = document.getElementById('total_harga_barang').innerHTML;

    arr[indexof].index = id;
    arr[indexof].nama_barang = nama_barang;
    arr[indexof].banyak_barang = banyak_barang;
    arr[indexof].harga_barang = harga_barang;
    arr[indexof].total_harga_barang = jumlah;
    // console.log(arr);

    let gettr = document.getElementById(id);
    gettr.children[0].innerHTML = "#";
    gettr.children[1].innerHTML = nama_barang;
    gettr.children[2].innerHTML = banyak_barang;
    gettr.children[3].innerHTML = Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(harga_barang);
    gettr.children[4].innerHTML = Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(jumlah);

    document.getElementById('nama_barang').value = "";
    document.getElementById('banyak_barang').value = "";
    document.getElementById('harga_barang').value = "";
    document.getElementById("total_harga_barang").innerHTML = "";

    penampung = 0;
    for(let i = 0; i<arr.length; i++){
        penampung += parseInt(arr[i]['total_harga_barang']);;
    }
    document.getElementById('total_semuanya').innerHTML = Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(penampung);;

    let onklik = document.querySelector("#save");
    onklik.setAttribute("onclick","simpanData()");
    onklik.innerHTML = "Tambahkan Barang";

}

function deleteData(id){
    let deleteid = confirm('Yakin ingin menghapus barang?');
            if (deleteid){
                let indexof = arr.findIndex(o => o.index === id);
                arr.splice(indexof,1);
                let gettbody = document.getElementById("show");
                let gettrindex = document.getElementById(id);
                gettbody.removeChild(gettrindex);

                penampung = 0;
                for(let i = 0; i<arr.length; i++){
                    penampung += parseInt(arr[i]['total_harga_barang']);
                }
                document.getElementById('total_semuanya').innerHTML = Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(penampung);
            }else{
                return false;
            }
}

function metodPembayaran(name){
    if(name == 'cash'){
        tampungPembayaran = 'Cash';
        console.log(tampungPembayaran);
        document.getElementById("metod_pembayaran1").checked = true;
        document.getElementById("metod_pembayaran2").checked = false;
        document.querySelector("#slotFile").removeChild(document.getElementById("slotFile").firstChild);
    }else if(name == 'transfer'){
        tampungPembayaran = 'Transfer';
        console.log(tampungPembayaran);
        document.getElementById("metod_pembayaran1").checked = false;
        document.getElementById("metod_pembayaran2").checked = true;
        document.getElementById("slotFile").innerHTML = "<div class='mb-3'><label for='formFile' class='form-label'>Masukkan Bukti Transfer</label><input class='form-control' type='file' id='formFile' accept='image/jpeg' onchange='return fileValidation()'></div>";
        // document.getElementById("coba").innerHTML = "<button onclick='coba()'>Coba</button>";
    }
}

function fileValidation(){
    var fileInput = document.getElementById('formFile');
    var filePath = fileInput.value;
    var sizeInput = fileInput.files[0].size;
    var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
    if (!allowedExtensions.exec(filePath)) {
        alert('File harus berupa gambar & Kurang dari 2mb');
        fileInput.value = '';
        return false;
    } else if (sizeInput > 2000000){
        alert('File harus berupa gambar & Kurang dari 2mb');
        fileInput.value = '';
        return false;
    }
}

function jenisTransaksi(name){
    if(name == 'pemasukan'){
        tampungJenisTransaksi = 'Pemasukan';
        // console.log(tampungJenisTransaksi);
        document.getElementById("jenis_transaksi1").checked = true;
        document.getElementById("jenis_transaksi2").checked = false;
    }else if(name == 'pengeluaran'){
        tampungJenisTransaksi = 'Pengeluaran';
        // console.log(tampungJenisTransaksi);
        document.getElementById("jenis_transaksi1").checked = false;
        document.getElementById("jenis_transaksi2").checked = true;
    }
}

// function coba(){
    
//     let anjay = {
//         'uhuy' : 'Anjay',
//     }

//     let uhuy = {
//         'anjay' : anjay,
//     }


//     if(tampungPembayaran == 'Cash'){
//         console.log(uhuy);
//     }else if(tampungPembayaran == 'Transfer'){
//         var input = document.querySelector('input[type="file"]');
//         tampungSemua = {
//             'anjay' : anjay,
//             'file' : input.files[0],
//         }
//         console.log(tampungSemua.file.name)
//     }
    
    
// }

