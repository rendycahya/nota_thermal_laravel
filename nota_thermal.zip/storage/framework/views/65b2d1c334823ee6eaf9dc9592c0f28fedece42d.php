<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="<?php echo e(asset('/img/kodehack.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/nota_css.css')); ?>">
    <title>KODEHACK | Page Nota Transaction</title>
</head>
<body class="fontBody">
    <div class="conta">
        <div class="headerKode">KODEHACK</div>
        <div class="alamat">Jl. Joyoboyo No.19, RT.6/RW.2,  
        <br>Medaeng, Waru, Sidoarjo, Jatim</div>
        <div class="notelp">Telp. 0851-5513-2241</div>
        <p class="border"></p>
        
        <div class="admin">Pembeli : <?php echo e($transaction->nama_pembeli); ?></div>
        <div class="admin">Admin : <?php echo e($transaction->pembuat); ?></div>
        <div class="tanggal"><?php echo e(\Carbon\Carbon::parse($transaction->created_at)->isoFormat('dddd, DD/MM/Y k:mm')); ?></div>
        
        <table class="table">
        <tbody >
            <?php $__currentLoopData = $detail_transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="barang" colspan="3"># <?php echo e($d->nama_barang); ?></td>
            </tr>
            <tr>
                <td class="harga"><?php echo e($d->harga_barang); ?></td>
                <td class="banyak_barang">x <?php echo e($d->banyak_barang); ?></td>
                <td class="total_harga">Rp <?php echo e(number_format($d->total_harga_barang,0,',','.')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="2" class="footer">Total :</td>
                <td colspan="1" class="inFooter">Rp <?php echo e(number_format($transaction->total_semua,0,',','.')); ?></td>
            </tr>
            <!-- <tr>
                <td colspan="2" class="pembeli">Pembeli :</td>
                <td colspan="1" class="inFooter"><?php echo e($transaction->nama_pembeli); ?></td>
            </tr> -->
            <tr>
                <td colspan="2" class="footer">Dibayar :</td>
                <td colspan="1" class="inFooter">Rp <?php echo e(number_format($transaction->uang_bayar,0,',','.')); ?></td>
                
            </tr>
            <tr>
                <td colspan="2" class="footer">Kembali :</td>
                <td colspan="1" class="inPembeli">Rp <?php echo e(number_format($transaction->uang_kembali,0,',','.')); ?></td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3"><p class="footerBorder"></p></td>
            </tr>
            <tr>
                <td class="center" colspan="3">
                    <div class="qr" ><?php echo QrCode::format('svg')->errorCorrection('L')->size(90)->style('square')->eye('square')->generate(Request::url()); ?></div>
                </td>
            </tr>
            <tr>
                <td colspan="3" class="lastFooter">kodehack.com</td>
            </tr>
          </tfoot>
        </table>

    </div>
    
</body>
</html>
<?php /**PATH C:\laragon\www\nota_thermal\resources\views/page_nota.blade.php ENDPATH**/ ?>